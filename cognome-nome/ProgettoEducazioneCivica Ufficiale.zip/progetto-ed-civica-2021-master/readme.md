Le immagini per la homepage devono essere 800x533 se orizzontali o 533x800 se verticali,
dovrete ridimensionare l’immagine in base alla casella a cui siete assegnati. inserite l'immagine 
nella cartella /img.

Creare una cartella "cognome-nome" con all'interno le pagine e le immagini usate 
per la pagina riguardante il proprio argomento.